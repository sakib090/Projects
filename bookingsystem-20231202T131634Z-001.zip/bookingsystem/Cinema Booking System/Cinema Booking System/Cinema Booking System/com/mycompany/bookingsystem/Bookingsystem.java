/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bookingsystem;

import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Bookingsystem {
    private static final Movie[] movies = { new Movie("Batman"), new Movie("Superman"), new Movie("Flash") };
    private static final Seat[][] seats = new Seat[5][5]; 
    private static final Showtime[] showtimes = {
        new Showtime("Morning", 10.0),
        new Showtime("Evening", 15.0),
        new Showtime("Night", 20.0)
    };
    private static Booking currentBooking;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        initializeSeats();

        System.out.println("Welcome to the Cinema Booking System");
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Select Movie" + (currentBooking != null && currentBooking.getMovie() != null ? " (Selected: " + currentBooking.getMovie().getTitle() + ")" : ""));
            System.out.println("2. Select Seat" + (currentBooking != null && currentBooking.getSeat() != null ? " (Selected: Row " + getRow(currentBooking.getSeat()) + " Seat " + getSeatNumber(currentBooking.getSeat()) + ")" : ""));
            System.out.println("3. Select Showtime" + (currentBooking != null && currentBooking.getShowtime() != null ? " (Selected: " + currentBooking.getShowtime().getTimeOfDay() + ")" : ""));
            System.out.println("4. Exit");
            System.out.println("5. Save Booking");
            System.out.println("6. Load Booking");

            int choice = 0;
            boolean validInput = false;
            while (!validInput) {
                try {
                    System.out.print("Enter your choice: ");
                    choice = scanner.nextInt();
                    validInput = true;
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next(); 
                }
            }

            switch (choice) {
                case 1:
                    selectMovie(scanner);
                    break;
                case 2:
                    selectSeat(scanner);
                    break;
                case 3:
                    selectShowtime(scanner);
                    break;
                case 4:
                    System.out.println("Thank you for using the Cinema Booking System.");
                    scanner.close();
                    return;
                case 5:
                    saveBooking();
                    break;
                case 6:
                    loadBooking();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void initializeSeats() {
        for (Seat[] seat : seats) {
            for (int j = 0; j < seat.length; j++) {
                seat[j] = new Seat();
            }
        }
    }

    private static void selectMovie(Scanner scanner) {
        System.out.println("Select a movie:");
        for (int i = 0; i < movies.length; i++) {
            System.out.println((i + 1) + ". " + movies[i].getTitle());
        }
        System.out.print("Enter your choice: ");
        int movieChoice = scanner.nextInt();
        if (movieChoice < 1 || movieChoice > movies.length) {
            System.out.println("Invalid choice. Please try again.");
            return;
        }
        Movie selectedMovie = movies[movieChoice - 1];
        currentBooking = new Booking(selectedMovie, null, null);
        System.out.println("You selected: " + selectedMovie.getTitle());
    }

    private static void selectSeat(Scanner scanner) {
    if (currentBooking == null || currentBooking.getMovie() == null) {
        System.out.println("Please select a movie first.");
        return;
    }
    System.out.println("Cinema Layout (X = available, O = booked):");
    displaySeats();

    int row = -1;
    int seatNumber = -1;
    boolean validRowInput = false;
    boolean validSeatInput = false;

    while (!validRowInput) {
        try {
            System.out.print("Enter row number: ");
            row = scanner.nextInt() - 1;
            if (row >= 0 && row < seats.length) {
                validRowInput = true;
            } else {
                System.out.println("Row number is out of bounds. Please try again.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a numeric value.");
            scanner.next(); 
        }
    }

    while (!validSeatInput) {
        try {
            System.out.print("Enter seat number: ");
            seatNumber = scanner.nextInt() - 1;
            if (seatNumber >= 0 && seatNumber < seats[row].length) {
                validSeatInput = true;
            } else {
                System.out.println("Seat number is out of bounds. Please try again.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a numeric value.");
            scanner.next(); 
        }
    }

    if (!seats[row][seatNumber].isAvailable()) {
        System.out.println("Invalid seat selection. Please try again.");
        return;
    }

    seats[row][seatNumber].bookSeat();
    currentBooking.setSeat(seats[row][seatNumber]);
    System.out.println("Seat selected: Row " + (row + 1) + " Seat " + (seatNumber + 1));
}


    private static void selectShowtime(Scanner scanner) {
        if (currentBooking == null || currentBooking.getSeat() == null) {
            System.out.println("Please select a seat first.");
            return;
        }
        System.out.println("Select a showtime:");
        for (int i = 0; i < showtimes.length; i++) {
            System.out.println((i + 1) + ". " + showtimes[i].getTimeOfDay() + " ($" + showtimes[i].getPrice() + ")");
        }
        System.out.print("Enter your choice: ");
        int showtimeChoice = scanner.nextInt();
        if (showtimeChoice < 1 || showtimeChoice > showtimes.length) {
            System.out.println("Invalid choice. Please try again.");
            return;
        }
        Showtime selectedShowtime = showtimes[showtimeChoice - 1];
        currentBooking.setShowtime(selectedShowtime);
        System.out.println("You selected: " + selectedShowtime.getTimeOfDay() + " Showtime");
    }


    private static void displaySeats() {
        System.out.println("   *** Screen ***");
        for (Seat[] seat1 : seats) {
            for (Seat seat : seat1) {
                System.out.print(seat + " ");
            }
            System.out.println();
        }
    }

    private static int getRow(Seat seat) {
        for (int i = 0; i < seats.length; i++) {
            for (Seat seat1 : seats[i]) {
                if (seat1 == seat) {
                    return i + 1;
                }
            }
        }
        return -1; // Seat not found
    }

    private static int getSeatNumber(Seat seat) {
        for (Seat[] seat1 : seats) {
            for (int j = 0; j < seat1.length; j++) {
                if (seat1[j] == seat) {
                    return j + 1;
                }
            }
        }
        return -1; // Seat not found
    }

    private static void saveBooking() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("save.file"))) {
            oos.writeObject(currentBooking);
            System.out.println("Booking saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving booking: " + e.getMessage());
        }
    }

    private static void loadBooking() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("save.file"))) {
            currentBooking = (Booking) ois.readObject();
            System.out.println("Booking loaded successfully.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading booking: " + e.getMessage());
        }
    }
}

class Movie implements Serializable {
    private final String title;

    public Movie(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}

class Seat implements Serializable{
    private boolean isAvailable;

    public Seat() {
        this.isAvailable = true;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void bookSeat() {
        this.isAvailable = false;
    }

    @Override
    public String toString() {
        return isAvailable ? "X" : "O";
    }
}

class Showtime implements Serializable {
    private final String timeOfDay;
    private final double price;

    public Showtime(String timeOfDay, double price) {
        this.timeOfDay = timeOfDay;
        this.price = price;
    }

    public String getTimeOfDay() {
        return timeOfDay;
    }

    public double getPrice() {
        return price;
    }
}

class Booking implements Serializable {
    private Movie movie;
    private Seat seat;
    private Showtime showtime;

    public Booking(Movie movie, Seat seat, Showtime showtime) {
        this.movie = movie;
        this.seat = seat;
        this.showtime = showtime;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public Seat getSeat() {
        return seat;
    }

    public void setSeat(Seat seat) {
        this.seat = seat;
    }

    public Showtime getShowtime() {
        return showtime;
    }

    public void setShowtime(Showtime showtime) {
        this.showtime = showtime;
    }
}
